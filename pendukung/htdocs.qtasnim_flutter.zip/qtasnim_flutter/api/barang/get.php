<?php
    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        include "../database.php";

        $sql = "SELECT id_barang, nama_barang FROM barang";
        
        $result = mysqli_query($db, $sql);
        $data   = array();
    
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
                $data[] = $row;
            }
        }
    
        echo json_encode(
            array(
                'message'   => 'request success',
                'result'    => $data,
            )
        );
    }
    else{
        echo json_encode(
            array(
                'message'   => 'method not allowed',
                'error'     => 404
            )
        );
    }
?>