<?php
    $server = "localhost";
    $user   = "root";
    $pass   = "";
    $name   = "db_qtasnim_flutter";

    $db     = new mysqli($server, $user, $pass, $name);

    if($db->connect_error){
        die("Connection Failed : ".$db->connect_error);
    }

?>