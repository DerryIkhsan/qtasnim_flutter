<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        include "../database.php";

        $id_transaksi   = @$_POST['id_transaksi'];
        $id_barang      = @$_POST['id_barang'];
        $jumlah         = @$_POST['jumlah'];


        $sql = "UPDATE transaksi SET id_barang = '$id_barang', jumlah = '$jumlah' WHERE id_transaksi = '$id_transaksi'";
        $result = mysqli_query($db, $sql);

        if($result){
            echo json_encode(
                array('message' => 'request success', 'success' => true)
            );
        }else{
            echo json_encode(
                array('message' => 'request failed')
            );
        }
    }
    else{
        echo json_encode(
            array(
                'message'   => 'method not allowed',
                'error'     => 404
            )
        );
    }
?>