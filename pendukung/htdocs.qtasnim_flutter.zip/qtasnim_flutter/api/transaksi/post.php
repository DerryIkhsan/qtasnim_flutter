<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        include "../database.php";

        $id_barang      = @$_POST['id_barang'];
        $jumlah         = @$_POST['jumlah'];
        $tgl            = date('Y-m-d');


        $sql = "INSERT INTO transaksi (id_barang, jumlah, tgl_transaksi) VALUES ('$id_barang', '$jumlah', '$tgl')";
        $result = mysqli_query($db, $sql);

        $id_transaksi = mysqli_insert_id($db);
        $sql_history = "INSERT INTO history_stok (id_transaksi) VALUES ('$id_transaksi')";
        mysqli_query($db, $sql_history);

        if($result){
            echo json_encode(
                array('message' => 'request success', 'success' => true)
            );
        }else{
            echo json_encode(
                array('message' => 'request failed')
            );
        }
    }
    else{
        echo json_encode(
            array(
                'message'   => 'method not allowed',
                'error'     => 404
            )
        );
    }
?>