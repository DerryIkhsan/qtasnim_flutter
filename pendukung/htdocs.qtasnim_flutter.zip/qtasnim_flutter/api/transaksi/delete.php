<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        include "../database.php";

        $id     = $_POST['id_transaksi'];

        $sql    = "DELETE FROM transaksi WHERE id_transaksi = '$id'";
        $result = mysqli_query($db, $sql);

        if($result){
            echo json_encode(
                array('message' => 'request success', 'success' => true)
            );
        }
        else{
            echo json_encode(
                array('message' => 'request failed')
            );
        }
    }
    else{
        echo json_encode(
            array(
                'message'   => 'method not allowed',
                'error'     => 404
            )
        );
    }
?>