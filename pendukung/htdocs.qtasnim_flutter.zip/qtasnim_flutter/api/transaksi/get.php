<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        include "../database.php";

        $nama_barang    = @$_POST['nama_barang'];
        $order          = @$_POST['order'];
        $order_by       = '';

        if($order != null OR $order != ''){
            $order_by = "ORDER BY $order ASC";
        }

        $sql = "SELECT b.id_barang, b.nama_barang, hs.stok_awal, t.id_transaksi, t.jumlah, t.tgl_transaksi, jb.jenis_barang FROM transaksi t
            JOIN barang b ON b.id_barang = t.id_barang
            JOIN jenis_barang jb ON jb.id_jenis_barang = b.id_jenis_barang
            JOIN history_stok hs ON hs.id_transaksi = t.id_transaksi
            WHERE b.nama_barang LIKE '%$nama_barang%' $order_by";
        
        $result = mysqli_query($db, $sql);
        $data   = array();
    
        if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
                $data[] = $row;
            }
        }
    
        echo json_encode(
            array(
                'message'   => 'request success',
                'result'    => $data,
            )
        );
    }
    else{
        echo json_encode(
            array(
                'message'   => 'method not allowed',
                'error'     => 404
            )
        );
    }
?>