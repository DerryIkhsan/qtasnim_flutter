<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        include "../database.php";

        $data               = array();
        $dataTerbanyak      = array();
        $dataTerendah       = array();

        $sqlTerbanyak = "SELECT 'Terbanyak' AS `data`, SUM(t.jumlah) AS total, b.nama_barang, jb.jenis_barang FROM transaksi t
            JOIN barang b ON b.id_barang = t.id_barang
            JOIN jenis_barang jb ON jb.id_jenis_barang = b.id_jenis_barang
            JOIN history_stok hs ON hs.id_transaksi = t.id_transaksi
            GROUP BY nama_barang
            ORDER BY total DESC LIMIT 1";
        
        $resultTerbanyak = mysqli_query($db, $sqlTerbanyak);
        
    
        if(mysqli_num_rows($resultTerbanyak) > 0){
            while($row = mysqli_fetch_assoc($resultTerbanyak)){
                $dataTerbanyak[] = $row;
            }
        }

        $sqlTerendah = "SELECT 'Terendah' AS `data`, SUM(t.jumlah) AS total, b.nama_barang, jb.jenis_barang FROM transaksi t
            JOIN barang b ON b.id_barang = t.id_barang
            JOIN jenis_barang jb ON jb.id_jenis_barang = b.id_jenis_barang
            JOIN history_stok hs ON hs.id_transaksi = t.id_transaksi
            GROUP BY nama_barang
            ORDER BY total ASC LIMIT 1";
        
        $resultTerendah = mysqli_query($db, $sqlTerendah);
        

        if(mysqli_num_rows($resultTerendah) > 0){
            while($row = mysqli_fetch_assoc($resultTerendah)){
                $dataTerendah[] = $row;
            }
        }

        $data[] = array_merge($dataTerbanyak, $dataTerendah);
    
        echo json_encode(
            array(
                'message'       => 'request success',
                'result'        => array_merge($dataTerbanyak, $dataTerendah),
            )
        );
    }
    else{
        echo json_encode(
            array(
                'message'   => 'method not allowed',
                'error'     => 404
            )
        );
    }
?>